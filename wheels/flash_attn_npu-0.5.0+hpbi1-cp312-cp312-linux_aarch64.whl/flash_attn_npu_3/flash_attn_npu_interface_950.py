# Copyright (c) 2023, Tri Dao.
# Modified by Minghua Shen, 2026.

from typing import Optional, Tuple, Union

import torch

# isort: off
import flash_attn_npu_3_950
# isort: on

if torch.__version__ >= "2.4.0":
    _torch_custom_op_wrapper = torch.library.custom_op
    _torch_register_fake_wrapper = torch.library.register_fake
else:

    def _noop_custom_op_wrapper(name, fn=None, /, *, mutates_args, device_types=None, schema=None):
        def wrap(func):
            return func

        if fn is None:
            return wrap
        return fn

    def _noop_register_fake_wrapper(op, fn=None, /, *, lib=None, _stacklevel=1):
        def wrap(func):
            return func

        if fn is None:
            return wrap
        return fn

    _torch_custom_op_wrapper = _noop_custom_op_wrapper
    _torch_register_fake_wrapper = _noop_register_fake_wrapper


_LAYOUT_TND = 0
_LAYOUT_BSND = 1
_LAYOUT_BNSD = 2


def _maybe_contiguous(x):
    """Make tensors fully contiguous for kernels that use linear GM offsets."""
    return x.contiguous() if x is not None and not x.is_contiguous() else x


def _transposed_bnsd_view(t):
    """``t.transpose(1, 2)`` if ``t`` is a contiguous BNSD tensor seen as BSND, else ``None``."""
    if t is None or t.dim() != 4 or t.is_contiguous():
        return None
    _, n1, _, n3 = t.shape
    if t.stride(3) == 1 and t.stride(1) == n3 and t.stride(2) == n1 * n3:
        return t.transpose(1, 2)
    return None


def _detect_layout(q, k, v, page_table, cu_seqlens_k):
    """Return ``(layout, q, k, v, out_transposed)``: the layout code shared with the C++
    host, the operands to hand the kernel, and whether ``out`` must be transposed back to
    match the shape of the query the caller passed in.

    Only a stride match selects BNSD; otherwise rank-4 operands are read as BSND. Paged and
    cu-packed (TND) Q/K/V are never BNSD.
    """
    if k is not None and v is not None and v.dim() != k.dim():
        raise RuntimeError(
            "flash_attn_npu_3_950: key and value must have the same rank for layout detection"
        )

    if q.dim() != 4 or k.dim() != 4 or page_table is not None or cu_seqlens_k is not None:
        return _LAYOUT_BSND, q, k, v, False

    q_bnsd = _transposed_bnsd_view(q)
    k_bnsd = _transposed_bnsd_view(k)
    v_bnsd = _transposed_bnsd_view(v)
    # A singleton sequence/head axis has identical BSND and BNSD storage.
    # Let a non-degenerate FP8 operand anchor layout detection for MQA and Q=1.
    if q.dtype == torch.float8_e4m3fn and any(x is not None for x in (q_bnsd, k_bnsd, v_bnsd)):
        if q_bnsd is None and q.is_contiguous() and (q.shape[1] == 1 or q.shape[2] == 1):
            q_bnsd = q.transpose(1, 2)
        if k_bnsd is None and k.is_contiguous() and (k.shape[1] == 1 or k.shape[2] == 1):
            k_bnsd = k.transpose(1, 2)
        if v_bnsd is None and v.is_contiguous() and (v.shape[1] == 1 or v.shape[2] == 1):
            v_bnsd = v.transpose(1, 2)
    if q_bnsd is not None and k_bnsd is not None and v_bnsd is not None:
        return _LAYOUT_BNSD, q_bnsd, k_bnsd, v_bnsd, True

    return _LAYOUT_BSND, q, k, v, False


@_torch_custom_op_wrapper(
    "flash_attn_npu_3_950_C::_flash_attn_forward", mutates_args=(), device_types="npu"
)
def _flash_attn_forward(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    k_new: Optional[torch.Tensor],
    v_new: Optional[torch.Tensor],
    qv: Optional[torch.Tensor],
    out: Optional[torch.Tensor],
    cu_seqlens_q: Optional[torch.Tensor],
    cu_seqlens_k: Optional[torch.Tensor],
    cu_seqlens_k_new: Optional[torch.Tensor],
    seqused_q: Optional[torch.Tensor],
    seqused_k: Optional[torch.Tensor],
    max_seqlen_q: Optional[int],
    max_seqlen_k: Optional[int],
    page_table: Optional[torch.Tensor],
    kv_batch_idx: Optional[torch.Tensor],
    leftpad_k: Optional[torch.Tensor],
    rotary_cos: Optional[torch.Tensor],
    rotary_sin: Optional[torch.Tensor],
    seqlens_rotary: Optional[torch.Tensor],
    q_descale: Optional[torch.Tensor],
    k_descale: Optional[torch.Tensor],
    v_descale: Optional[torch.Tensor],
    softmax_scale: Optional[float],
    causal: bool,
    window_size_left: int,
    window_size_right: int,
    attention_chunk: int,
    softcap: float,
    rotary_interleaved: bool,
    scheduler_metadata: Optional[torch.Tensor],
    num_splits: int,
    pack_gqa: Optional[bool],
    sm_margin: int,
    return_softmax_lse: bool,
    layout: int,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    q, k, k_new, v_new = (_maybe_contiguous(x) for x in (q, k, k_new, v_new))
    v = v.contiguous() if v.stride(-1) != 1 and v.stride(-3) != 1 else v
    q_descale, k_descale, v_descale = (
        _maybe_contiguous(x) for x in (q_descale, k_descale, v_descale)
    )
    cu_seqlens_q, cu_seqlens_k, cu_seqlens_k_new = (
        _maybe_contiguous(x) for x in (cu_seqlens_q, cu_seqlens_k, cu_seqlens_k_new)
    )
    seqused_q, seqused_k = (_maybe_contiguous(x) for x in (seqused_q, seqused_k))
    page_table, kv_batch_idx, leftpad_k = (
        _maybe_contiguous(x) for x in (page_table, kv_batch_idx, leftpad_k)
    )
    rotary_cos, rotary_sin = (_maybe_contiguous(x) for x in (rotary_cos, rotary_sin))
    seqlens_rotary = _maybe_contiguous(seqlens_rotary)

    out_t, softmax_lse, out_accum, softmax_lse_accum = flash_attn_npu_3_950.fwd(
        q,
        k,
        v,
        k_new,
        v_new,
        qv,
        out,
        cu_seqlens_q,
        cu_seqlens_k,
        cu_seqlens_k_new,
        seqused_q,
        seqused_k,
        max_seqlen_q,
        max_seqlen_k,
        page_table,
        kv_batch_idx,
        leftpad_k,
        rotary_cos,
        rotary_sin,
        seqlens_rotary,
        q_descale,
        k_descale,
        v_descale,
        softmax_scale,
        causal,
        window_size_left,
        window_size_right,
        attention_chunk,
        softcap,
        rotary_interleaved,
        scheduler_metadata,
        num_splits,
        pack_gqa,
        sm_margin,
        return_softmax_lse,
        layout,
    )

    if out_accum is None:
        out_accum = torch.tensor([], device=out_t.device)
    if softmax_lse_accum is None:
        softmax_lse_accum = torch.tensor([], device=out_t.device)

    return out_t, softmax_lse, out_accum, softmax_lse_accum


@_torch_register_fake_wrapper("flash_attn_npu_3_950_C::_flash_attn_forward")
def _flash_attn_forward_fake(
    q,
    k,
    v,
    k_new,
    v_new,
    qv,
    out,
    cu_seqlens_q,
    cu_seqlens_k,
    cu_seqlens_k_new,
    seqused_q,
    seqused_k,
    max_seqlen_q,
    max_seqlen_k,
    page_table,
    kv_batch_idx,
    leftpad_k,
    rotary_cos,
    rotary_sin,
    seqlens_rotary,
    q_descale,
    k_descale,
    v_descale,
    softmax_scale,
    causal,
    window_size_left,
    window_size_right,
    attention_chunk,
    softcap,
    rotary_interleaved,
    scheduler_metadata,
    num_splits,
    pack_gqa,
    sm_margin,
    return_softmax_lse,
    layout,
):
    is_varlen_q = cu_seqlens_q is not None
    out_dtype = torch.bfloat16 if q.dtype == torch.float8_e4m3fn else q.dtype
    head_size_v = v.size(-1)

    if is_varlen_q:
        total_q = q.size(0)
        num_heads = q.size(1)
        out = torch.empty((total_q, num_heads, head_size_v), dtype=out_dtype, device=q.device)
        softmax_lse = (
            torch.empty((num_heads, total_q), dtype=torch.float32, device=q.device)
            if return_softmax_lse
            else torch.empty((0,), dtype=torch.float32, device=q.device)
        )
    else:
        if layout == _LAYOUT_BNSD:
            batch_size, num_heads, seqlen_q, _ = q.shape
        else:
            batch_size, seqlen_q, num_heads, _ = q.shape
        out = torch.empty(
            (batch_size, seqlen_q, num_heads, head_size_v), dtype=out_dtype, device=q.device
        )
        softmax_lse = (
            torch.empty((batch_size, num_heads, seqlen_q), dtype=torch.float32, device=q.device)
            if return_softmax_lse
            else torch.empty((0,), dtype=torch.float32, device=q.device)
        )

    out_accum = torch.tensor([], device=q.device)
    softmax_lse_accum = torch.tensor([], device=q.device)
    return out, softmax_lse, out_accum, softmax_lse_accum


@_torch_custom_op_wrapper(
    "flash_attn_npu_3_950_C::_flash_attn_backward",
    mutates_args=("dq", "dk", "dv"),
    device_types="npu",
)
def _flash_attn_backward(
    dout: torch.Tensor,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    out: torch.Tensor,
    softmax_lse: torch.Tensor,
    cu_seqlens_q: Optional[torch.Tensor] = None,
    cu_seqlens_k: Optional[torch.Tensor] = None,
    seqused_q: Optional[torch.Tensor] = None,
    seqused_k: Optional[torch.Tensor] = None,
    max_seqlen_q: Optional[int] = None,
    max_seqlen_k: Optional[int] = None,
    dq: Optional[torch.Tensor] = None,
    dk: Optional[torch.Tensor] = None,
    dv: Optional[torch.Tensor] = None,
    softmax_scale: Optional[float] = None,
    is_causal: bool = False,
    window_size_left: int = -1,
    window_size_right: int = -1,
    softcap: float = 0.0,
    deterministic: bool = False,
    sm_margin: int = 0,
) -> torch.Tensor:
    # Same storage detection as forward; retain logical BSND shapes for host/output.
    if cu_seqlens_q is not None:
        layout = _LAYOUT_TND
    else:
        layout = _detect_layout(q, k, v, None, cu_seqlens_k)[0]

    dout, q, k, v, out = [x.contiguous() if x.stride(-1) != 1 else x for x in (dout, q, k, v, out)]
    softmax_lse = softmax_lse.contiguous()
    _, _, _, softmax_d = flash_attn_npu_3_950.bwd(
        dout,
        q,
        k,
        v,
        out,
        softmax_lse,
        dq,
        dk,
        dv,
        cu_seqlens_q,
        cu_seqlens_k,
        seqused_q,
        seqused_k,
        max_seqlen_q,
        max_seqlen_k,
        softmax_scale,
        is_causal,
        window_size_left,
        window_size_right,
        softcap,
        deterministic,
        sm_margin,
        layout,
    )
    return softmax_d


@_torch_register_fake_wrapper("flash_attn_npu_3_950_C::_flash_attn_backward")
def _flash_attn_backward_fake(
    dout,
    q,
    k,
    v,
    out,
    softmax_lse,
    cu_seqlens_q=None,
    cu_seqlens_k=None,
    seqused_q=None,
    seqused_k=None,
    max_seqlen_q=None,
    max_seqlen_k=None,
    dq=None,
    dk=None,
    dv=None,
    softmax_scale=None,
    is_causal=False,
    window_size_left=-1,
    window_size_right=-1,
    softcap=0.0,
    deterministic=False,
    sm_margin=0,
):
    del (
        dout,
        k,
        v,
        out,
        softmax_lse,
        cu_seqlens_k,
        seqused_q,
        seqused_k,
        max_seqlen_k,
        softmax_scale,
        is_causal,
        window_size_left,
        window_size_right,
        softcap,
        deterministic,
        sm_margin,
    )
    if cu_seqlens_q is None:
        batch_size, seqlen_q, num_heads = q.shape[:3]
        return torch.empty(
            (batch_size, num_heads, seqlen_q),
            dtype=torch.float32,
            device=q.device,
        )
    return torch.empty(
        (q.shape[1], q.shape[0]),
        dtype=torch.float32,
        device=q.device,
    )


@_torch_custom_op_wrapper(
    "flash_attn_npu_3_950::_get_scheduler_metadata",
    mutates_args=(),
    device_types="npu",
)
def _get_scheduler_metadata_op(
    batch_size: int,
    max_seqlen_q: int,
    num_heads_q: int,
    num_heads_kv: int,
    headdim: int,
    headdim_v: int,
    cache_seqlens: torch.Tensor,
    seqlens_q: Optional[torch.Tensor],
    cu_seqlens_k: Optional[torch.Tensor],
    page_size: Optional[int],
    causal: bool,
    has_softcap: bool,
    num_splits: int,
    max_seqlen_k: int,
    window_left: int,
    window_right: int,
    quant_mode: int = 0,
) -> torch.Tensor:
    return flash_attn_npu_3_950.get_scheduler_metadata(
        batch_size,
        max_seqlen_q,
        num_heads_q,
        num_heads_kv,
        headdim,
        headdim_v,
        cache_seqlens,
        seqlens_q,
        cu_seqlens_k,
        page_size,
        causal,
        has_softcap,
        num_splits,
        max_seqlen_k,
        window_left,
        window_right,
        quant_mode,
    )


@_torch_register_fake_wrapper("flash_attn_npu_3_950::_get_scheduler_metadata")
def _get_scheduler_metadata_fake(
    batch_size: int,
    max_seqlen_q: int,
    num_heads_q: int,
    num_heads_kv: int,
    headdim: int,
    headdim_v: int,
    cache_seqlens: torch.Tensor,
    seqlens_q: Optional[torch.Tensor],
    cu_seqlens_k: Optional[torch.Tensor],
    page_size: Optional[int],
    causal: bool,
    has_softcap: bool,
    num_splits: int,
    max_seqlen_k: int,
    window_left: int,
    window_right: int,
    quant_mode: int = 0,
) -> torch.Tensor:
    ctx = torch.library.get_ctx()
    metadata_size = ctx.new_dynamic_size()

    return torch.empty(
        (metadata_size,),
        dtype=torch.uint8,
        device=cache_seqlens.device,
    )


def get_scheduler_metadata(
    batch_size,
    max_seqlen_q,
    max_seqlen_k,
    num_heads_q,
    num_heads_kv,
    headdim,
    cache_seqlens: torch.Tensor,
    qkv_dtype=torch.bfloat16,
    headdim_v=None,
    cu_seqlens_q: Optional[torch.Tensor] = None,
    cu_seqlens_k_new: Optional[torch.Tensor] = None,
    cache_leftpad: Optional[torch.Tensor] = None,
    page_size: Optional[int] = None,
    max_seqlen_k_new=0,
    causal=False,
    window_size=(-1, -1),  # -1 means infinite context window
    attention_chunk=0,
    has_softcap=False,
    num_splits=0,  # Can be tuned for speed
    pack_gqa=None,  # Can be tuned for speed
    sm_margin=0,  # Can be tuned if some SMs are used for communication
):
    """Precompute AICPU scheduler metadata (tiling + kvCum) on Ascend 950.

    The signature matches the upstream flash-attention FA3
    ``get_scheduler_metadata`` and the 910 V3 implementation. The returned NPU
    byte tensor can be passed to ``flash_attn_with_kvcache`` through its
    ``scheduler_metadata`` argument to avoid per-call host tiling and H2D/D2H
    copies.

    The schedule is independent of ``has_softcap`` and of the numerical
    ``softmax_scale`` / softcap value: those are supplied by each forward call
    through its tiling, so a single metadata buffer can be reused across
    different scale / softcap settings. Re-create it only when the shapes,
    layout, causal / window flags or per-batch sequence lengths change.
    """
    cache_seqlens = _maybe_contiguous(cache_seqlens)
    seqlens_q = cu_seqlens_q[1:] - cu_seqlens_q[:-1] if cu_seqlens_q is not None else None
    if seqlens_q is not None:
        seqlens_q = _maybe_contiguous(seqlens_q)
    if headdim_v is None:
        headdim_v = headdim
    if qkv_dtype not in (torch.float16, torch.bfloat16, torch.float8_e4m3fn):
        raise ValueError("qkv_dtype must be FP16, BF16 or FP8_E4M3FN")
    quant_mode = 1 if qkv_dtype == torch.float8_e4m3fn else 0
    if cu_seqlens_k_new is not None or max_seqlen_k_new:
        raise ValueError("Ascend 950 does not support append-KV (cu_seqlens_k_new)")
    if cache_leftpad is not None:
        raise ValueError("Ascend 950 does not support leftpad_k")
    if attention_chunk != 0:
        raise ValueError("Ascend 950 does not support attention_chunk")
    if pack_gqa is not None and pack_gqa:
        raise ValueError("Ascend 950 does not support pack_gqa")
    scheduler_metadata = _get_scheduler_metadata_op(
        batch_size,
        max_seqlen_q,
        num_heads_q,
        num_heads_kv,
        headdim,
        headdim_v,
        cache_seqlens,
        seqlens_q,
        None,  # kv lengths come from cache_seqlens
        page_size,
        causal,
        has_softcap,
        num_splits,
        max_seqlen_k,
        window_size[0],
        window_size[1],
        quant_mode,
    )
    return scheduler_metadata


def _training_forward(
    q,
    k,
    v,
    cu_seqlens_q,
    cu_seqlens_k,
    max_seqlen_q,
    max_seqlen_k,
    softmax_scale,
    softcap,
    causal,
    window_size,
    scheduler_metadata,
    seqused_q=None,
    seqused_k=None,
    layout=_LAYOUT_BSND,
    q_descale=None,
    k_descale=None,
    v_descale=None,
):
    if seqused_k is None:
        if cu_seqlens_q is None:
            kv_seqlen = k.shape[2] if layout == _LAYOUT_BNSD else k.shape[1]
            seqused_k = torch.full(
                (q.shape[0],),
                kv_seqlen,
                dtype=torch.int32,
                device=k.device,
            )
        else:
            seqused_k = cu_seqlens_k[1:] - cu_seqlens_k[:-1]

    return _flash_attn_forward(
        q,
        k,
        v,
        None,
        None,
        None,
        None,  # k_new, v_new, qv, out
        cu_seqlens_q,
        cu_seqlens_k,
        None,  # cu_seqlens_k_new
        seqused_q,
        seqused_k,
        max_seqlen_q,
        max_seqlen_k,
        None,
        None,
        None,  # page_table, kv_batch_idx, leftpad_k
        None,
        None,
        None,  # rotary
        q_descale,
        k_descale,
        v_descale,  # descales
        softmax_scale,
        causal,
        window_size[0],
        window_size[1],
        0,
        softcap,
        True,
        scheduler_metadata,
        1,
        None,
        0,
        True,  # return_softmax_lse (needed by the backward)
        layout,
    )


class FlashAttnFunc(torch.autograd.Function):
    @staticmethod
    def forward(
        ctx,
        q,
        k,
        v,
        softmax_scale,
        causal,
        qv,
        q_descale,
        k_descale,
        v_descale,
        window_size,
        attention_chunk,
        softcap,
        num_splits,
        pack_gqa,
        deterministic,
        sm_margin,
        return_softmax,
        scheduler_metadata,
    ):
        if qv is not None:
            raise NotImplementedError("Ascend950 v3 training scaffold only supports q/k/v inputs")
        if attention_chunk != 0:
            raise NotImplementedError(
                "Ascend950 v3 training scaffold does not support attention_chunk"
            )
        if num_splits not in (0, 1) or pack_gqa not in (None, False) or sm_margin != 0:
            raise NotImplementedError(
                "Ascend950 v3 training scaffold does not support split/pack/sm tuning"
            )
        if softmax_scale is None:
            softmax_scale = q.shape[-1] ** (-0.5)
        quant_mode = 1 if q.dtype == torch.float8_e4m3fn else 0

        # get_scheduler_metadata only takes numbers and reads them as BSND, so the sizes
        # below come from the pre-detection shapes; BNSD only re-views the same storage.
        batch_size, seqlen_q, num_heads_q, headdim = q.shape
        seqlen_k, num_heads_kv = k.shape[1], k.shape[2]
        headdim_v = v.shape[3]

        layout, q, k, v, out_transposed = _detect_layout(q, k, v, None, None)
        if scheduler_metadata is None:
            meta_cache_seqlens = torch.full(
                (batch_size,), seqlen_k, dtype=torch.int32, device=q.device
            )
            scheduler_metadata = get_scheduler_metadata(
                batch_size=batch_size,
                max_seqlen_q=seqlen_q,
                max_seqlen_k=seqlen_k,
                num_heads_q=num_heads_q,
                num_heads_kv=num_heads_kv,
                headdim=headdim,
                headdim_v=headdim_v,
                cache_seqlens=meta_cache_seqlens,
                qkv_dtype=q.dtype,
                causal=causal,
                window_size=window_size,
                has_softcap=softcap > 0.0,
                num_splits=num_splits,
            )

        out, softmax_lse, _, _ = _training_forward(
            q,
            k,
            v,
            None,
            None,
            None,
            None,
            softmax_scale,
            softcap,
            causal,
            window_size,
            scheduler_metadata,
            layout=layout,
            q_descale=q_descale,
            k_descale=k_descale,
            v_descale=v_descale,
        )
        ctx.quant_mode = quant_mode
        ctx.save_for_backward(q, k, v, out, softmax_lse)
        ctx.softmax_scale = softmax_scale
        ctx.softcap = softcap
        ctx.causal = causal
        ctx.window_size = tuple(window_size)
        ctx.deterministic = deterministic
        ctx.sm_margin = sm_margin
        return (out, softmax_lse.transpose(-1, -2)) if return_softmax else out

    @staticmethod
    def backward(ctx, dout, *unused_grads):
        if ctx.quant_mode == 1:
            raise NotImplementedError("Ascend950 V3 FP8 supports forward only")
        q, k, v, out, softmax_lse = ctx.saved_tensors
        dq, dk, dv = torch.empty_like(q), torch.empty_like(k), torch.empty_like(v)
        _flash_attn_backward(
            dout,
            q,
            k,
            v,
            out,
            softmax_lse,
            None,
            None,
            None,
            None,
            None,
            None,
            dq,
            dk,
            dv,
            ctx.softmax_scale,
            ctx.causal,
            ctx.window_size[0],
            ctx.window_size[1],
            ctx.softcap,
            ctx.deterministic,
            ctx.sm_margin,
        )
        return dq, dk, dv, *((None,) * 15)


class FlashAttnVarlenFunc(torch.autograd.Function):
    @staticmethod
    def forward(
        ctx,
        q,
        k,
        v,
        cu_seqlens_q,
        cu_seqlens_k,
        seqused_q,
        seqused_k,
        max_seqlen_q,
        max_seqlen_k,
        softmax_scale,
        causal,
        qv,
        q_descale,
        k_descale,
        v_descale,
        window_size,
        attention_chunk,
        softcap,
        num_splits,
        pack_gqa,
        deterministic,
        sm_margin,
        return_softmax,
        scheduler_metadata,
    ):
        if qv is not None:
            raise NotImplementedError("Ascend950 v3 does not support qv")
        if attention_chunk != 0:
            raise NotImplementedError(
                "Ascend950 v3 training scaffold does not support attention_chunk"
            )
        if num_splits not in (0, 1) or pack_gqa not in (None, False) or sm_margin != 0:
            raise NotImplementedError(
                "Ascend950 v3 training scaffold does not support split/pack/sm tuning"
            )
        if softmax_scale is None:
            softmax_scale = q.shape[-1] ** (-0.5)
        quant_mode = 1 if q.dtype == torch.float8_e4m3fn else 0

        seqused_q = _maybe_contiguous(seqused_q)
        seqused_k = _maybe_contiguous(seqused_k)
        # The packed varlen query (cu_seqlens_q present) is always TND, never BNSD.
        layout = _LAYOUT_TND
        if scheduler_metadata is None:
            meta_seqused_k = (
                seqused_k
                if seqused_k is not None
                else _maybe_contiguous(cu_seqlens_k[1:] - cu_seqlens_k[:-1])
            )
            meta_seqlens_q = (
                seqused_q
                if seqused_q is not None
                else _maybe_contiguous(cu_seqlens_q[1:] - cu_seqlens_q[:-1])
            )
            # Internal scheduler takes the used lengths; the public helper takes cu_seqlens_q.
            scheduler_metadata = _get_scheduler_metadata_op(
                cu_seqlens_q.numel() - 1,
                max_seqlen_q,
                q.shape[1],
                k.shape[1],
                q.shape[2],
                v.shape[2],
                meta_seqused_k,
                meta_seqlens_q,
                None,  # cu_seqlens_k
                None,  # page_size
                causal,
                softcap > 0.0,
                num_splits,
                max_seqlen_k,
                window_size[0],
                window_size[1],
                quant_mode,
            )

        out, softmax_lse, _, _ = _training_forward(
            q,
            k,
            v,
            cu_seqlens_q,
            cu_seqlens_k,
            max_seqlen_q,
            max_seqlen_k,
            softmax_scale,
            softcap,
            causal,
            window_size,
            scheduler_metadata,
            seqused_q,
            seqused_k,
            layout=layout,
            q_descale=q_descale,
            k_descale=k_descale,
            v_descale=v_descale,
        )
        ctx.quant_mode = quant_mode
        ctx.save_for_backward(
            q, k, v, out, softmax_lse, cu_seqlens_q, cu_seqlens_k, seqused_q, seqused_k
        )
        ctx.max_seqlen_q = max_seqlen_q
        ctx.max_seqlen_k = max_seqlen_k
        ctx.softmax_scale = softmax_scale
        ctx.softcap = softcap
        ctx.causal = causal
        ctx.window_size = tuple(window_size)
        ctx.deterministic = deterministic
        ctx.sm_margin = sm_margin
        return (out, softmax_lse.transpose(-1, -2)) if return_softmax else out

    @staticmethod
    def backward(ctx, dout, *unused_grads):
        if ctx.quant_mode == 1:
            raise NotImplementedError("Ascend950 V3 FP8 supports forward only")
        q, k, v, out, softmax_lse, cu_q, cu_k, seqused_q, seqused_k = ctx.saved_tensors
        dq, dk, dv = torch.empty_like(q), torch.empty_like(k), torch.empty_like(v)
        _flash_attn_backward(
            dout,
            q,
            k,
            v,
            out,
            softmax_lse,
            cu_q,
            cu_k,
            seqused_q,
            seqused_k,
            ctx.max_seqlen_q,
            ctx.max_seqlen_k,
            dq,
            dk,
            dv,
            ctx.softmax_scale,
            ctx.causal,
            ctx.window_size[0],
            ctx.window_size[1],
            ctx.softcap,
            ctx.deterministic,
            ctx.sm_margin,
        )
        return dq, dk, dv, *((None,) * 21)


def flash_attn_func(
    q,
    k,
    v,
    softmax_scale=None,
    causal=False,
    qv=None,
    q_descale=None,
    k_descale=None,
    v_descale=None,
    window_size=(-1, -1),
    attention_chunk=0,
    softcap=0.0,
    num_splits=1,
    pack_gqa=None,
    deterministic=False,
    sm_margin=0,
    return_attn_probs=False,
):
    return FlashAttnFunc.apply(
        q,
        k,
        v,
        softmax_scale,
        causal,
        qv,
        q_descale,
        k_descale,
        v_descale,
        window_size,
        attention_chunk,
        softcap,
        num_splits,
        pack_gqa,
        deterministic,
        sm_margin,
        return_attn_probs,
        None,
    )


def flash_attn_varlen_func(
    q,
    k,
    v,
    cu_seqlens_q,
    cu_seqlens_k,
    max_seqlen_q,
    max_seqlen_k,
    seqused_q=None,
    seqused_k=None,
    softmax_scale=None,
    causal=False,
    qv=None,
    q_descale=None,
    k_descale=None,
    v_descale=None,
    window_size=(-1, -1),
    attention_chunk=0,
    softcap=0.0,
    num_splits=1,
    pack_gqa=None,
    deterministic=False,
    sm_margin=0,
    return_attn_probs=False,
):
    return FlashAttnVarlenFunc.apply(
        q,
        k,
        v,
        cu_seqlens_q,
        cu_seqlens_k,
        seqused_q,
        seqused_k,
        max_seqlen_q,
        max_seqlen_k,
        softmax_scale,
        causal,
        qv,
        q_descale,
        k_descale,
        v_descale,
        window_size,
        attention_chunk,
        softcap,
        num_splits,
        pack_gqa,
        deterministic,
        sm_margin,
        return_attn_probs,
        None,
    )


def flash_attn_with_kvcache(
    q,
    k_cache,
    v_cache,
    k=None,
    v=None,
    qv=None,
    rotary_cos=None,
    rotary_sin=None,
    cache_seqlens: Optional[Union[int, torch.Tensor]] = None,
    cache_batch_idx: Optional[torch.Tensor] = None,
    cache_leftpad: Optional[torch.Tensor] = None,
    page_table: Optional[torch.Tensor] = None,
    cu_seqlens_q: Optional[torch.Tensor] = None,
    cu_seqlens_k_new: Optional[torch.Tensor] = None,
    max_seqlen_q: Optional[int] = None,
    rotary_seqlens: Optional[torch.Tensor] = None,
    q_descale: Optional[torch.Tensor] = None,
    k_descale: Optional[torch.Tensor] = None,
    v_descale: Optional[torch.Tensor] = None,
    softmax_scale=None,
    causal=False,
    window_size=(-1, -1),
    attention_chunk=0,
    softcap=0.0,
    rotary_interleaved=True,
    scheduler_metadata=None,
    num_splits=0,
    pack_gqa=None,
    sm_margin=0,
    return_softmax_lse=False,
):
    """
    If k and v are not None, k_cache and v_cache will be updated *inplace* with the new values from
    k and v. This is useful for incremental decoding: you can pass in the cached keys/values from
    the previous step, and update them with the new keys/values from the current step, and do
    attention with the updated cache, all in 1 kernel.

    If you pass in k / v, you must make sure that the cache is large enough to hold the new values.
    For example, the KV cache could be pre-allocated with the max sequence length, and you can use
    cache_seqlens to keep track of the current sequence lengths of each sequence in the batch.

    Also apply rotary embedding if rotary_cos and rotary_sin are passed in. The key @k will be
    rotated by rotary_cos and rotary_sin at indices cache_seqlens, cache_seqlens + 1, etc.
    If causal or local (i.e., window_size != (-1, -1)), the query @q will be rotated by rotary_cos
    and rotary_sin at indices cache_seqlens, cache_seqlens + 1, etc.
    If not causal and not local, the query @q will be rotated by rotary_cos and rotary_sin at
    indices cache_seqlens only (i.e. we consider all tokens in @q to be at position cache_seqlens).

    See tests/test_flash_attn.py::test_flash_attn_kvcache for examples of how to use this function.

    Supports multi-query and grouped-query attention (MQA/GQA) by passing in KV with fewer heads
    than Q. Note that the number of heads in Q must be divisible by the number of heads in KV.
    For example, if Q has 6 heads and K, V have 2 heads, head 0, 1, 2 of Q will attention to head
    0 of K, V, and head 3, 4, 5 of Q will attention to head 1 of K, V.

    If causal=True, the causal mask is aligned to the bottom right corner of the attention matrix.
    For example, if seqlen_q = 2 and seqlen_k = 5, the causal mask (1 = keep, 0 = masked out) is:
        1 1 1 1 0
        1 1 1 1 1
    If seqlen_q = 5 and seqlen_k = 2, the causal mask is:
        0 0
        0 0
        0 0
        1 0
        1 1
    If the row of the mask is all zero, the output will be zero.

    If window_size != (-1, -1), implements sliding window local attention. Query at position i
    will only attend to keys between
    [i + seqlen_k - seqlen_q - window_size[0], i + seqlen_k - seqlen_q + window_size[1]] inclusive.

    Note: Does not support backward pass.

    Arguments:
        q: (batch_size, seqlen, nheads, headdim)
        k_cache: (batch_size_cache, seqlen_cache, nheads_k, headdim) if there's no page_table,
            or (num_blocks, page_block_size, nheads_k, headdim) if there's a page_table (i.e. paged KV cache)
            When cu_seqlens_q is provided (TND), non-paged cache must be 3D:
            (total_tokens, nheads_k, headdim).
            page_block_size can be arbitrary (e.g, 1, 2, 3, 64, etc.).
        v_cache: (batch_size_cache, seqlen_cache, nheads_k, headdim_v) if there's no page_table,
            or (num_blocks, page_block_size, nheads_k, headdim_v) if there's a page_table (i.e. paged KV cache)
            When cu_seqlens_q is provided (TND), non-paged cache must be 3D:
            (total_tokens, nheads_k, headdim_v).
        k [optional]: (batch_size, seqlen_new, nheads_k, headdim). If not None, we concatenate
            k with k_cache, starting at the indices specified by cache_seqlens.
        v [optional]: (batch_size, seqlen_new, nheads_k, headdim_v). Similar to k.
        qv [optional]: (batch_size, seqlen, nheads, headdim_v)
        rotary_cos [optional]: (seqlen_ro, rotary_dim / 2). If not None, we apply rotary embedding
            to k and q. Only applicable if k and v are passed in. rotary_dim must be divisible by 16.
        rotary_sin [optional]: (seqlen_ro, rotary_dim / 2). Similar to rotary_cos.
        cache_seqlens: int, or (batch_size,), dtype torch.int32. The sequence lengths of the
            KV cache.
        cache_batch_idx: (batch_size,), dtype torch.int32. The indices used to index into the KV cache.
            If None, we assume that the batch indices are [0, 1, 2, ..., batch_size - 1].
            If the indices are not distinct, and k and v are provided, the values updated in the cache
                 might come from any of the duplicate indices.
        cache_leftpad: (batch_size,), dtype torch.int32. The index that the KV cache starts. If None, assume 0.
        page_table [optional]: (batch_size, max_num_blocks_per_seq), dtype torch.int32.
        softmax_scale: float. The scaling of QK^T before applying softmax.
            Default to 1 / sqrt(headdim).
        causal: bool. Whether to apply causal attention mask (e.g., for auto-regressive modeling).
        window_size: (left, right). If not (-1, -1), implements sliding window local attention.
        softcap: float. Anything > 0 activates softcapping attention.
        rotary_interleaved: bool. Only applicable if rotary_cos and rotary_sin are passed in.
            If True, rotary embedding will combine dimensions 0 & 1, 2 & 3, etc. If False,
            rotary embedding will combine dimensions 0 & rotary_dim / 2, 1 & rotary_dim / 2 + 1
            (i.e. GPT-NeoX style).
        num_splits: int. If > 1, split the key/value into this many chunks along the sequence.
           If num_splits == 1, we don't split the key/value. If num_splits == 0, we use a heuristic
           to automatically determine the number of splits.
           Don't change this unless you know what you are doing.
        return_softmax_lse: bool. Whether to return the logsumexp of the attention scores.

    Return:
        out: (batch_size, seqlen, nheads, headdim).
        softmax_lse [optional, if return_softmax_lse=True]: (batch_size, nheads, seqlen). The
            logsumexp of each row of the matrix QK^T * scaling (e.g., log of the softmax
            normalization factor).
    """
    assert k_cache.stride(-1) == 1, "k_cache must have contiguous last dimension"
    assert v_cache.stride(-1) == 1, "v_cache must have contiguous last dimension"

    if softmax_scale is None:
        softmax_scale = q.shape[-1] ** (-0.5)

    if cache_seqlens is not None and isinstance(cache_seqlens, int):
        num_batch = cu_seqlens_q.numel() - 1 if cu_seqlens_q is not None else q.shape[0]
        cache_seqlens = torch.full(
            (num_batch,), cache_seqlens, dtype=torch.int32, device=k_cache.device
        )
        cache_seqlens = _maybe_contiguous(cache_seqlens)

    # cu_seqlens_q pins the layout to TND; otherwise _detect_layout picks BSND or BNSD.
    if cu_seqlens_q is not None:
        layout, out_transposed = _LAYOUT_TND, False
    else:
        # get_scheduler_metadata only takes numbers and reads them as BSND, so the sizes
        # below come from the pre-detection shapes; BNSD only re-views the same storage.
        bsnd_batch, bsnd_seqlen_q, bsnd_heads_q, bsnd_headdim = q.shape
        bsnd_seqlen_k, bsnd_heads_kv = k_cache.shape[1], k_cache.shape[2]
        bsnd_headdim_v = v_cache.shape[-1]
        layout, q, k_cache, v_cache, out_transposed = _detect_layout(
            q, k_cache, v_cache, page_table, None
        )

    # FlashDecode schedules depend on the runtime KV lengths and are produced
    # by the host tiler.  Keep the upstream metadata path for normal FA, but
    # do not pre-build metadata for explicit FD or for the narrow auto-FD
    # candidate shape.
    auto_fd_candidate = (
        num_splits == 0
        and page_table is not None
        and cu_seqlens_q is not None
        and max_seqlen_q is not None
        and max_seqlen_q <= 16
    )
    use_host_tiling = num_splits > 1 or auto_fd_candidate
    if scheduler_metadata is None and not use_host_tiling:
        if cu_seqlens_q is not None:
            if max_seqlen_q is None:
                raise ValueError("max_seqlen_q must be provided when cu_seqlens_q is provided")
            batch_size = cu_seqlens_q.numel() - 1
            num_heads_q = q.shape[1]
            headdim = q.shape[2]
            headdim_v = v_cache.shape[-1]
            kv_heads = k_cache.shape[1] if k_cache.dim() == 3 else k_cache.shape[2]
            max_q = max_seqlen_q
        else:
            batch_size = bsnd_batch
            num_heads_q = bsnd_heads_q
            headdim = bsnd_headdim
            headdim_v = bsnd_headdim_v
            kv_heads = bsnd_heads_kv
            max_q = bsnd_seqlen_q
        if page_table is not None:
            page_size = k_cache.shape[1]
            max_blocks = page_table.shape[1]
        else:
            page_size = None
            max_blocks = None
        if cache_seqlens is not None:
            max_seqlen_k_bound = int(cache_seqlens.max().item())
            # BNSD gives every head a max_q_seqlen-wide KV plane, so the per-batch KV
            # lengths must fit the allocated sequence dim. The host tiler enforces the
            # same invariant on the non-metadata path.
            if out_transposed and max_seqlen_k_bound > bsnd_seqlen_k:
                raise ValueError(
                    "flash_attn_npu_3_950: BNSD KV sequence dimension "
                    f"({bsnd_seqlen_k}) is too small to cover the actual KV length "
                    f"({max_seqlen_k_bound})"
                )
        elif page_table is not None:
            max_seqlen_k_bound = max_blocks * page_size
        elif cu_seqlens_q is not None:
            max_seqlen_k_bound = k_cache.shape[0]  # TND 3D non-paged fallback
        else:
            max_seqlen_k_bound = bsnd_seqlen_k
        scheduler_metadata = get_scheduler_metadata(
            batch_size=batch_size,
            max_seqlen_q=max_q,
            max_seqlen_k=max_seqlen_k_bound,
            num_heads_q=num_heads_q,
            num_heads_kv=kv_heads,
            headdim=headdim,
            headdim_v=headdim_v,
            cache_seqlens=cache_seqlens,
            qkv_dtype=q.dtype,
            cu_seqlens_q=cu_seqlens_q,
            page_size=page_size,
            causal=causal,
            window_size=window_size,
            has_softcap=softcap > 0.0,
            num_splits=num_splits,
        )
    out, softmax_lse, *rest = _flash_attn_forward(
        q,
        k_cache,
        v_cache,
        k,
        v,
        qv,
        None,  # out (let the kernel allocate)
        cu_seqlens_q,
        None,  # cu_seqlens_k
        cu_seqlens_k_new,
        None,  # seqused_q
        cache_seqlens,  # seqused_k — required by the 950 wrapper
        max_seqlen_q,
        None,  # max_seqlen_k
        page_table,
        cache_batch_idx,
        cache_leftpad,
        rotary_cos,
        rotary_sin,
        rotary_seqlens,
        q_descale,
        k_descale,
        v_descale,
        softmax_scale,
        causal=causal,
        window_size_left=window_size[0],
        window_size_right=window_size[1],
        attention_chunk=attention_chunk,
        softcap=softcap,
        rotary_interleaved=rotary_interleaved,
        scheduler_metadata=scheduler_metadata,
        num_splits=num_splits,
        pack_gqa=pack_gqa,
        sm_margin=sm_margin,
        return_softmax_lse=return_softmax_lse,
        layout=layout,
    )
    return (out, softmax_lse, *rest) if return_softmax_lse else out


@_torch_custom_op_wrapper(
    "flash_attn_npu_3_950_C::_flash_attn_combine",
    mutates_args=("out",),
    device_types="npu",
)
def _flash_attn_combine_op(
    out_partial: torch.Tensor,
    lse_partial: torch.Tensor,
    out: torch.Tensor,
    out_dtype: Optional[torch.dtype],
) -> torch.Tensor:
    return flash_attn_npu_3_950.fwd_combine(out_partial, lse_partial, out, out_dtype)[1]


@_torch_register_fake_wrapper("flash_attn_npu_3_950_C::_flash_attn_combine")
def _flash_attn_combine_fake(
    out_partial: torch.Tensor,
    lse_partial: torch.Tensor,
    out: torch.Tensor,
    out_dtype: Optional[torch.dtype],
) -> torch.Tensor:
    is_dense = out_partial.dim() == 5
    lse_shape = (
        (out_partial.shape[1], out_partial.shape[2], out_partial.shape[3])
        if is_dense
        else (out_partial.shape[1], out_partial.shape[2])
    )
    return torch.empty(lse_shape, dtype=torch.float32, device=out.device)


def flash_attn_combine(out_partial, lse_partial, out=None, out_dtype=None):
    """Merge split-KV partial attention outputs (Ascend 950 backend).

    See ``flash_attn_npu_3.flash_attn_combine`` for the full contract; this
    backend shares the same NV-aligned signature.
    """
    if out is None:
        output_dtype = out_dtype or out_partial.dtype
        out_shape = (
            out_partial.shape[1:4] + (out_partial.shape[4],)
            if out_partial.dim() == 5
            else out_partial.shape[1:2] + out_partial.shape[2:4]
        )
        out = torch.empty(out_shape, dtype=output_dtype, device=out_partial.device)
    lse = _flash_attn_combine_op(out_partial, lse_partial, out, out_dtype)
    return out, lse
