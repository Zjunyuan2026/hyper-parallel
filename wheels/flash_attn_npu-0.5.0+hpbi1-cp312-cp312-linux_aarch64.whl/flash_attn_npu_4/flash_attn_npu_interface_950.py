# Copyright (c) 2023, Tri Dao.
# Modified by Minghua Shen, 2026.

from typing import Any, Callable, Optional, Tuple

import torch

# isort: off
import flash_attn_npu_4_950
# isort: on

if torch.__version__ >= "2.4.0":
    _torch_custom_op_wrapper = torch.library.custom_op
    _torch_register_fake_wrapper = torch.library.register_fake
else:

    def _noop_custom_op_wrapper(name, fn=None, /, *, mutates_args, device_types=None, schema=None):
        def wrap(func):
            return func

        if fn is None:
            return wrap
        return fn

    def _noop_register_fake_wrapper(op, fn=None, /, *, lib=None, _stacklevel=1):
        def wrap(func):
            return func

        if fn is None:
            return wrap
        return fn

    _torch_custom_op_wrapper = _noop_custom_op_wrapper
    _torch_register_fake_wrapper = _noop_register_fake_wrapper


_LAYOUT_TND = 0
_LAYOUT_BSND = 1
_LAYOUT_BNSD = 2


def _maybe_contiguous(x):
    return x.contiguous() if x is not None and x.stride(-1) != 1 else x


def _full_contiguous(x):
    """Linear GM operands (backward tensors and descales) need full contiguity;
    ``_maybe_contiguous`` only guarantees stride(-1) == 1, which
    permuted last-dim-minor views also satisfy."""
    return x.contiguous() if x is not None and not x.is_contiguous() else x


def _window_to_npu(window_size: Optional[int]) -> int:
    return -1 if window_size is None else int(window_size)


def _transposed_bnsd_view(t):
    """``t.transpose(1, 2)`` if ``t`` is a contiguous BNSD tensor seen as BSND, else ``None``."""
    if t is None or t.dim() != 4 or t.is_contiguous():
        return None
    _, n1, _, n3 = t.shape
    if t.stride(3) == 1 and t.stride(1) == n3 and t.stride(2) == n1 * n3:
        return t.transpose(1, 2)
    return None


def _detect_layout(q, k, v, page_table, cu_seqlens_k):
    """Return ``(layout, q, k, v, out_transposed)``: the layout code shared with the C++
    host, the operands to hand the kernel, and whether ``out`` must be transposed back to
    match the shape of the query the caller passed in.

    Only a stride match selects BNSD; otherwise rank-4 operands are read as BSND. Paged and
    cu-packed (TND) Q/K/V are never BNSD.
    """
    if k is not None and v is not None and v.dim() != k.dim():
        raise RuntimeError(
            "flash_attn_npu_4_950: key and value must have the same rank for layout detection"
        )

    if q.dim() != 4 or k.dim() != 4 or page_table is not None or cu_seqlens_k is not None:
        return _LAYOUT_BSND, q, k, v, False

    q_bnsd = _transposed_bnsd_view(q)
    k_bnsd = _transposed_bnsd_view(k)
    v_bnsd = _transposed_bnsd_view(v)
    # A singleton sequence/head axis has identical BSND and BNSD storage.
    # Let a non-degenerate FP8 operand anchor layout detection for MQA and Q=1.
    if q.dtype == torch.float8_e4m3fn and any(x is not None for x in (q_bnsd, k_bnsd, v_bnsd)):
        if q_bnsd is None and q.is_contiguous() and (q.shape[1] == 1 or q.shape[2] == 1):
            q_bnsd = q.transpose(1, 2)
        if k_bnsd is None and k.is_contiguous() and (k.shape[1] == 1 or k.shape[2] == 1):
            k_bnsd = k.transpose(1, 2)
        if v_bnsd is None and v.is_contiguous() and (v.shape[1] == 1 or v.shape[2] == 1):
            v_bnsd = v.transpose(1, 2)
    if q_bnsd is not None and k_bnsd is not None and v_bnsd is not None:
        return _LAYOUT_BNSD, q_bnsd, k_bnsd, v_bnsd, True

    return _LAYOUT_BSND, q, k, v, False


# Ascend950 FA4 metadata contains only serialized FAInferStaticTilingData. Keep
# this in sync with fa_metadata::MetadataBytes(false) in
# csrc/ascend950/flash_attn_npu_4/fa_metadata_args.h.  Unlike the FA3
# metadata, its size does not depend on the input sequence lengths or mask.
_SCHEDULER_METADATA_TILING_BYTES = 5216


@_torch_custom_op_wrapper(
    "flash_attn_npu_4_950::_get_scheduler_metadata",
    mutates_args=(),
    device_types="npu",
)
def _get_scheduler_metadata_op(
    batch_size: int,
    max_seqlen_q: int,
    max_seqlen_k: int,
    num_heads_q: int,
    num_heads_kv: int,
    headdim: int,
    headdim_v: int,
    cache_seqlens: torch.Tensor,
    cu_seqlens_q: Optional[torch.Tensor],
    causal: bool,
    window_size_left: int,
    window_size_right: int,
    num_splits: int,
    pack_gqa: Optional[bool],
    sm_margin: int,
    seqused_q: Optional[torch.Tensor] = None,
    quant_mode: int = 0,
) -> torch.Tensor:
    # Keep the raw pybind call behind a torch.library op.  Calling a pybind
    # function directly from a torch.compile graph is treated as an opaque
    # Python/C++ builtin and causes a Dynamo graph break.
    return flash_attn_npu_4_950.get_scheduler_metadata(
        batch_size,
        max_seqlen_q,
        max_seqlen_k,
        num_heads_q,
        num_heads_kv,
        headdim,
        headdim_v,
        cache_seqlens,
        cu_seqlens_q,
        causal,
        window_size_left,
        window_size_right,
        num_splits,
        pack_gqa,
        sm_margin,
        seqused_q,
        quant_mode,
    )


@_torch_register_fake_wrapper("flash_attn_npu_4_950::_get_scheduler_metadata")
def _get_scheduler_metadata_fake(
    batch_size: int,
    max_seqlen_q: int,
    max_seqlen_k: int,
    num_heads_q: int,
    num_heads_kv: int,
    headdim: int,
    headdim_v: int,
    cache_seqlens: torch.Tensor,
    cu_seqlens_q: Optional[torch.Tensor],
    causal: bool,
    window_size_left: int,
    window_size_right: int,
    num_splits: int,
    pack_gqa: Optional[bool],
    sm_margin: int,
    seqused_q: Optional[torch.Tensor] = None,
    quant_mode: int = 0,
) -> torch.Tensor:
    # The metadata is an opaque byte buffer during tracing.  Ascend950 FA4
    # serializes one fixed-size FAInferStaticTilingData object, so returning
    # a static shape lets Dynamo keep the custom op in the graph.
    return torch.empty(
        (_SCHEDULER_METADATA_TILING_BYTES,),
        dtype=torch.uint8,
        device=cache_seqlens.device,
    )


def get_scheduler_metadata(
    max_seqlen_q,
    max_seqlen_k,
    nheads,
    nheads_kv,
    headdim,
    num_splits,
    headdim_v=None,
    pack_gqa=None,
    causal=False,
    window_size_left=None,
    window_size_right=None,
    seqlen_k_new=0,
    cu_seqlens_q: Optional[torch.Tensor] = None,
    cu_seqlens_k: Optional[torch.Tensor] = None,
    cu_seqlens_k_new: Optional[torch.Tensor] = None,
    seqused_q: Optional[torch.Tensor] = None,
    seqused_k: Optional[torch.Tensor] = None,
    leftpad_k: Optional[torch.Tensor] = None,
    seqlen_k_per_split: Optional[int] = None,
    _arch: Optional[int] = None,
    qkv_dtype: Optional[torch.dtype] = None,
):
    """Precompute Ascend 950 FA4 metadata using the Tri Dao FA4 signature.

    Ascend FA4 does not support KV updates, padded BSND Q lengths, left padding, or
    fixed split lengths. Those Tri Dao parameters remain as compatibility
    placeholders and must retain their default unsupported values.
    """
    if seqlen_k_new != 0:
        raise ValueError("Ascend 950 FA4 does not support seqlen_k_new")
    if cu_seqlens_k_new is not None:
        raise ValueError("Ascend 950 FA4 does not support cu_seqlens_k_new")
    if leftpad_k is not None:
        raise ValueError("Ascend 950 FA4 does not support leftpad_k")
    if seqlen_k_per_split is not None:
        raise ValueError("Ascend 950 FA4 does not support seqlen_k_per_split")
    if _arch is not None:
        raise ValueError("Ascend 950 FA4 does not accept _arch")
    if cu_seqlens_q is not None:
        cu_seqlens_q = _maybe_contiguous(cu_seqlens_q)
    if cu_seqlens_k is not None:
        cu_seqlens_k = _maybe_contiguous(cu_seqlens_k)
    if seqused_q is not None:
        seqused_q = _maybe_contiguous(seqused_q)
    if seqused_k is None:
        if cu_seqlens_k is None:
            raise ValueError("seqused_k or cu_seqlens_k is required")
        seqused_k = cu_seqlens_k[1:] - cu_seqlens_k[:-1]
    seqused_k = _maybe_contiguous(seqused_k)
    batch_size = seqused_k.numel()
    if cu_seqlens_q is not None and cu_seqlens_q.numel() != batch_size + 1:
        raise ValueError("cu_seqlens_q batch size does not match seqused_k")
    if seqused_q is not None and seqused_q.numel() != batch_size:
        raise ValueError("seqused_q batch size does not match seqused_k")
    if headdim_v is None:
        headdim_v = headdim
    if window_size_left is None:
        window_size_left = -1
    if window_size_right is None:
        window_size_right = -1
    if pack_gqa is not None and pack_gqa:
        raise ValueError("Ascend 950 FA4 does not support pack_gqa=True")
    return _get_scheduler_metadata_op(
        batch_size,
        max_seqlen_q,
        max_seqlen_k,
        nheads,
        nheads_kv,
        headdim,
        headdim_v,
        seqused_k,
        cu_seqlens_q,
        causal,
        window_size_left,
        window_size_right,
        num_splits,
        pack_gqa,
        0,
        seqused_q,
        int(qkv_dtype == torch.float8_e4m3fn),
    )


@_torch_custom_op_wrapper(
    "flash_attn_npu_4_C::_flash_attn_forward", mutates_args=(), device_types="npu"
)
def _flash_attn_forward(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    qv: Optional[torch.Tensor] = None,
    out_: Optional[torch.Tensor] = None,
    cu_seqlens_q: Optional[torch.Tensor] = None,
    cu_seqlens_k: Optional[torch.Tensor] = None,
    max_seqlen_q: Optional[int] = None,
    max_seqlen_k: Optional[int] = None,
    min_seqlen_k: Optional[int] = None,
    seqused_q: Optional[torch.Tensor] = None,
    seqused_k: Optional[torch.Tensor] = None,
    gather_kv_indices: Optional[torch.Tensor] = None,
    page_table: Optional[torch.Tensor] = None,
    softmax_scale: Optional[float] = None,
    causal: bool = False,
    window_size_left: int = -1,
    window_size_right: int = -1,
    learnable_sink: Optional[torch.Tensor] = None,
    softcap: float = 0.0,
    num_splits: int = 0,
    pack_gqa: Optional[bool] = None,
    return_lse: bool = False,
    scheduler_metadata: Optional[torch.Tensor] = None,
    layout: int = _LAYOUT_BSND,
    q_descale: Optional[torch.Tensor] = None,
    k_descale: Optional[torch.Tensor] = None,
    v_descale: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    q, k = (_maybe_contiguous(x) for x in (q, k))
    v = v.contiguous() if v.stride(-1) != 1 and v.stride(-3) != 1 else v
    cu_seqlens_q, cu_seqlens_k = (_maybe_contiguous(x) for x in (cu_seqlens_q, cu_seqlens_k))
    seqused_q, seqused_k = (_maybe_contiguous(x) for x in (seqused_q, seqused_k))
    page_table = _maybe_contiguous(page_table)
    q_descale, k_descale, v_descale = (
        _full_contiguous(x) for x in (q_descale, k_descale, v_descale)
    )

    out_t, softmax_lse, out_accum, softmax_lse_accum = flash_attn_npu_4_950.fwd(
        q,
        k,
        v,
        qv,
        out_,
        cu_seqlens_q,
        cu_seqlens_k,
        seqused_q,
        seqused_k,
        max_seqlen_q,
        max_seqlen_k,
        min_seqlen_k,
        page_table,
        gather_kv_indices,
        softmax_scale,
        causal,
        window_size_left,
        window_size_right,
        softcap,
        num_splits,
        pack_gqa,
        learnable_sink,
        return_lse,
        scheduler_metadata,
        layout,
        q_descale,
        k_descale,
        v_descale,
    )

    if out_accum is None:
        out_accum = torch.tensor([], device=out_t.device)
    if softmax_lse_accum is None:
        softmax_lse_accum = torch.tensor([], device=out_t.device)

    return out_t, softmax_lse, out_accum, softmax_lse_accum


@_torch_custom_op_wrapper(
    "flash_attn_npu_4_950_C::_flash_attn_backward_op",
    mutates_args=("dq", "dk", "dv"),
    device_types="npu",
)
def _flash_attn_backward_op(
    dout: torch.Tensor,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    out: torch.Tensor,
    softmax_lse: torch.Tensor,
    cu_seqlens_q: Optional[torch.Tensor],
    cu_seqlens_k: Optional[torch.Tensor],
    seqused_q: Optional[torch.Tensor],
    seqused_k: Optional[torch.Tensor],
    max_seqlen_q: Optional[int],
    max_seqlen_k: Optional[int],
    dq: torch.Tensor,
    dk: torch.Tensor,
    dv: torch.Tensor,
    softmax_scale: Optional[float],
    causal: bool,
    window_size_left: int,
    window_size_right: int,
    softcap: float,
    deterministic: bool,
) -> torch.Tensor:
    # Same storage detection as forward; retain logical BSND shapes for host/output.
    if cu_seqlens_q is not None:
        layout = _LAYOUT_TND
    else:
        layout = _detect_layout(q, k, v, None, cu_seqlens_k)[0]

    dout, q, k, v, out = [x.contiguous() if x.stride(-1) != 1 else x for x in (dout, q, k, v, out)]
    softmax_lse = softmax_lse.contiguous()
    _dq, _dk, _dv, softmax_d = flash_attn_npu_4_950.bwd(
        dout,
        q,
        k,
        v,
        out,
        softmax_lse,
        dq,
        dk,
        dv,
        cu_seqlens_q,
        cu_seqlens_k,
        seqused_q,
        seqused_k,
        max_seqlen_q,
        max_seqlen_k,
        softmax_scale,
        causal,
        window_size_left,
        window_size_right,
        softcap,
        deterministic,
        0,  # sm_margin
        layout,
    )
    return softmax_d


@_torch_register_fake_wrapper("flash_attn_npu_4_950_C::_flash_attn_backward_op")
def _flash_attn_backward_op_fake(
    dout: torch.Tensor,
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    out: torch.Tensor,
    softmax_lse: torch.Tensor,
    cu_seqlens_q: Optional[torch.Tensor],
    cu_seqlens_k: Optional[torch.Tensor],
    max_seqlen_q: Optional[int],
    max_seqlen_k: Optional[int],
    dq: torch.Tensor,
    dk: torch.Tensor,
    dv: torch.Tensor,
    softmax_scale: Optional[float],
    causal: bool,
    window_size_left: int,
    window_size_right: int,
    softcap: float,
    deterministic: bool,
) -> torch.Tensor:
    """Metadata-only fake for V4 A2 backward_op. Returns softmax_d; mutates dq/dk/dv."""
    is_varlen_q = cu_seqlens_q is not None
    if is_varlen_q:
        batch_size = cu_seqlens_q.shape[0] - 1
        nheads = q.shape[1]
        # Real mha_bwd always allocates (batch, nheads, max_seqlen_q).
        seqlen_q = max_seqlen_q
    else:
        batch_size = q.shape[0]
        nheads = q.shape[2]
        seqlen_q = q.shape[1]

    softmax_d = torch.empty((batch_size, nheads, seqlen_q), dtype=torch.float32, device=q.device)
    return softmax_d


def _flash_attn_backward(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    out: torch.Tensor,
    dout: torch.Tensor,
    lse: torch.Tensor,
    softmax_scale: Optional[float] = None,
    causal: bool = False,
    softcap: float = 0.0,
    window_size_left: Optional[int] = None,
    window_size_right: Optional[int] = None,
    cu_seqlens_q: Optional[torch.Tensor] = None,
    cu_seqlens_k: Optional[torch.Tensor] = None,
    seqused_q: Optional[torch.Tensor] = None,
    seqused_k: Optional[torch.Tensor] = None,
    max_seqlen_q: Optional[int] = None,
    max_seqlen_k: Optional[int] = None,
    deterministic: bool = False,
    dq: Optional[torch.Tensor] = None,
    dk: Optional[torch.Tensor] = None,
    dv: Optional[torch.Tensor] = None,
    dlse: Optional[torch.Tensor] = None,
    score_mod: Optional[Callable] = None,
    score_mod_bwd: Optional[Callable] = None,
    mask_mod: Optional[Callable] = None,
    aux_tensors: Optional[list] = None,
    aux_scalars: Optional[tuple] = None,
    block_sparse_tensors: Optional[Any] = None,
    qv: Optional[torch.Tensor] = None,
    page_table: Optional[torch.Tensor] = None,
    gather_kv_indices: Optional[torch.Tensor] = None,
    learnable_sink: Optional[torch.Tensor] = None,
    pack_gqa: bool = False,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    del dlse

    assert score_mod is None, "flash_attn_npu_v4 950 bwd does not support score_mod"
    assert score_mod_bwd is None, "flash_attn_npu_v4 950 bwd does not support score_mod_bwd"
    assert mask_mod is None, "flash_attn_npu_v4 950 bwd does not support mask_mod"
    assert aux_tensors is None, "flash_attn_npu_v4 950 bwd does not support aux_tensors"
    assert aux_scalars is None, "flash_attn_npu_v4 950 bwd does not support aux_scalars"
    assert block_sparse_tensors is None, (
        "flash_attn_npu_v4 950 bwd does not support block_sparse_tensors"
    )
    assert not pack_gqa, "flash_attn_npu_v4 950 bwd does not support pack_gqa=True"
    assert qv is None, "flash_attn_npu_v4 950 bwd does not support qv"
    assert page_table is None, "flash_attn_npu_v4 950 bwd does not support page_table"
    assert gather_kv_indices is None, "flash_attn_npu_v4 950 bwd does not support gather_kv_indices"
    assert learnable_sink is None, "flash_attn_npu_v4 950 bwd does not support learnable_sink"

    if dq is None:
        dq = torch.empty(q.shape, dtype=q.dtype, device=q.device)
    if dk is None:
        dk = torch.empty(k.shape, dtype=k.dtype, device=k.device)
    if dv is None:
        dv = torch.empty(v.shape, dtype=v.dtype, device=v.device)

    seqused_q_c = _full_contiguous(seqused_q) if seqused_q is not None else None
    seqused_k_c = _full_contiguous(seqused_k) if seqused_k is not None else None
    _flash_attn_backward_op(
        dout,
        q,
        k,
        v,
        out,
        lse,
        cu_seqlens_q,
        cu_seqlens_k,
        seqused_q_c,
        seqused_k_c,
        max_seqlen_q,
        max_seqlen_k,
        dq,
        dk,
        dv,
        softmax_scale,
        causal,
        _window_to_npu(window_size_left),
        _window_to_npu(window_size_right),
        softcap,
        deterministic,
    )
    return dq, dk, dv


_flash_attn_bwd = _flash_attn_backward


class FlashAttnFunc(torch.autograd.Function):
    @staticmethod
    def forward(
        ctx,
        q,
        k,
        v,
        qv=None,
        gather_kv_indices=None,
        softmax_scale=None,
        causal=False,
        window_size=(-1, -1),
        learnable_sink=None,
        softcap=0.0,
        num_splits=1,
        pack_gqa=None,
        deterministic=False,
        score_mod=None,
        score_mod_bwd=None,
        mask_mod=None,
        aux_tensors=None,
        aux_scalars=None,
        block_sparse_tensors=None,
        block_sparse_tensors_bwd=None,
        return_lse=False,
        scheduler_metadata=None,
        disable_scheduler_metadata=False,
    ):
        assert k.stride(-1) == 1, "k must have contiguous last dimension"
        assert v.stride(-1) == 1, "v must have contiguous last dimension"

        if softmax_scale is None:
            softmax_scale = q.shape[-1] ** (-0.5)

        # get_scheduler_metadata only takes numbers and reads them as BSND, so the sizes
        # below come from the pre-detection shapes; BNSD only re-views the same storage.
        batch_size, seqlen_q, nheads, headdim = q.shape
        seqlen_k, nheads_kv = k.shape[1], k.shape[2]
        headdim_v = v.shape[-1]

        layout, q, k, v, out_transposed = _detect_layout(q, k, v, None, None)

        seqused_k = torch.full(
            (batch_size,),
            seqlen_k,
            dtype=torch.int32,
            device=q.device,
        )

        # Precompute the scheduler metadata, including FlashDecode schedules
        # when eligible, on the AICPU so the forward launch needs no
        # device->host->device round trip.
        if scheduler_metadata is None and not disable_scheduler_metadata:
            scheduler_metadata = get_scheduler_metadata(
                max_seqlen_q=seqlen_q,
                max_seqlen_k=seqlen_k,
                nheads=nheads,
                nheads_kv=nheads_kv,
                headdim=headdim,
                num_splits=num_splits,
                headdim_v=headdim_v,
                pack_gqa=pack_gqa,
                causal=causal,
                window_size_left=window_size[0],
                window_size_right=window_size[1],
                seqused_k=seqused_k,
                qkv_dtype=q.dtype,
            )

        out, softmax_lse, out_accum, softmax_lse_accum = _flash_attn_forward(
            q,
            k,
            v,
            qv,
            None,
            None,
            None,
            None,
            None,
            None,
            None,
            seqused_k,
            gather_kv_indices,
            None,
            softmax_scale,
            causal,
            window_size[0],
            window_size[1],
            learnable_sink,
            softcap,
            num_splits,
            pack_gqa,
            True,
            scheduler_metadata,
            layout,
        )

        ctx.save_for_backward(q, k, v, out, softmax_lse)
        ctx.softmax_scale = softmax_scale
        ctx.causal = causal
        ctx.window_size = window_size
        ctx.softcap = softcap
        ctx.deterministic = deterministic
        ctx.return_lse = return_lse
        ctx.pack_gqa = pack_gqa
        ctx.qv = qv
        ctx.gather_kv_indices = gather_kv_indices
        ctx.learnable_sink = learnable_sink
        ctx.score_mod = score_mod
        ctx.score_mod_bwd = score_mod_bwd
        ctx.mask_mod = mask_mod
        ctx.block_sparse_tensors = block_sparse_tensors
        ctx.aux_tensors = aux_tensors
        ctx.aux_scalars = aux_scalars

        if return_lse:
            return out, softmax_lse
        return out

    @staticmethod
    def backward(ctx, dout, *args):
        q, k, v, out, softmax_lse = ctx.saved_tensors
        dlse = args[0] if ctx.return_lse and len(args) > 0 else None
        if dlse is not None and torch.is_tensor(dlse) and float(dlse.detach().abs().sum()) == 0.0:
            dlse = None
        win_l, win_r = ctx.window_size
        if win_l is not None and win_l < 0:
            win_l = None
        if win_r is not None and win_r < 0:
            win_r = None

        dq, dk, dv = _flash_attn_backward(
            q,
            k,
            v,
            out,
            dout,
            softmax_lse,
            softmax_scale=ctx.softmax_scale,
            causal=ctx.causal,
            softcap=ctx.softcap,
            window_size_left=win_l,
            window_size_right=win_r,
            cu_seqlens_q=None,
            cu_seqlens_k=None,
            seqused_q=None,
            seqused_k=None,
            max_seqlen_q=None,
            max_seqlen_k=None,
            deterministic=ctx.deterministic,
            pack_gqa=bool(ctx.pack_gqa) if ctx.pack_gqa is not None else False,
            score_mod=ctx.score_mod,
            score_mod_bwd=ctx.score_mod_bwd,
            mask_mod=ctx.mask_mod,
            aux_tensors=ctx.aux_tensors,
            aux_scalars=ctx.aux_scalars,
            block_sparse_tensors=ctx.block_sparse_tensors,
            dlse=dlse,
            qv=ctx.qv,
            page_table=None,
            gather_kv_indices=ctx.gather_kv_indices,
            learnable_sink=ctx.learnable_sink,
        )
        return (
            dq,
            dk,
            dv,
            None,  # qv
            None,  # gather_kv_indices
            None,  # softmax_scale
            None,  # causal
            None,  # window_size
            None,  # learnable_sink
            None,  # softcap
            None,  # num_splits
            None,  # pack_gqa
            None,  # deterministic
            None,  # score_mod
            None,  # score_mod_bwd
            None,  # mask_mod
            None,  # aux_tensors
            None,  # aux_scalars
            None,  # block_sparse_tensors
            None,  # block_sparse_tensors_bwd
            None,  # return_lse
            None,  # scheduler_metadata
            None,  # disable_scheduler_metadata
        )


class FlashAttnVarlenFunc(torch.autograd.Function):
    @staticmethod
    def forward(
        ctx,
        q,
        k,
        v,
        qv=None,
        cu_seqlens_q=None,
        cu_seqlens_k=None,
        max_seqlen_q=None,
        max_seqlen_k=None,
        min_seqlen_k=None,
        seqused_q=None,
        seqused_k=None,
        gather_kv_indices=None,
        page_table=None,
        softmax_scale=None,
        causal=False,
        window_size=(-1, -1),
        learnable_sink=None,
        softcap=0.0,
        num_splits=0,
        pack_gqa=None,
        deterministic=False,
        score_mod=None,
        score_mod_bwd=None,
        mask_mod=None,
        block_sparse_tensors=None,
        aux_tensors=None,
        aux_scalars=None,
        return_lse=False,
        scheduler_metadata=None,
        disable_scheduler_metadata=False,
    ):
        assert k.stride(-1) == 1, "k must have contiguous last dimension"
        assert v.stride(-1) == 1, "v must have contiguous last dimension"
        # BNSD is not a varlen layout, so this path only picks TND or BSND.
        layout = _LAYOUT_TND if cu_seqlens_q is not None else _LAYOUT_BSND

        if softmax_scale is None:
            softmax_scale = q.shape[-1] ** (-0.5)

        if seqused_k is None and cu_seqlens_k is not None:
            seqused_k = cu_seqlens_k[1:] - cu_seqlens_k[:-1]
        if seqused_q is None and cu_seqlens_q is not None:
            seqused_q = cu_seqlens_q[1:] - cu_seqlens_q[:-1]

        if seqused_k is not None and isinstance(seqused_k, int):
            seqused_k = torch.full((q.shape[0],), seqused_k, dtype=torch.int32, device=k.device)
        seqused_q = _maybe_contiguous(seqused_q)
        seqused_k = _maybe_contiguous(seqused_k)

        # Precompute the scheduler metadata, including FlashDecode schedules
        # when eligible, on the AICPU so the forward launch needs no
        # device->host->device round trip.
        kv_seqlens = seqused_k
        if kv_seqlens is None and cu_seqlens_k is not None:
            kv_seqlens = cu_seqlens_k[1:] - cu_seqlens_k[:-1]
        # The forward launch normalizes the SWA window against max_seqlen_k. A
        # declared bound can be looser than the actual lengths (paged KV: the
        # page capacity), so when the caller does not pin it, use the actual
        # max KV length for both the metadata and the forward launch. Otherwise
        # a finite window that covers the real lengths but not the capacity
        # fails to collapse and produces the wrong mask.
        fwd_max_seqlen_k = max_seqlen_k
        if scheduler_metadata is None and not disable_scheduler_metadata and kv_seqlens is not None:
            kv_seqlens = _maybe_contiguous(kv_seqlens)
            if max_seqlen_q is None:
                metadata_max_seqlen_q = q.shape[0] if q.dim() == 3 else q.shape[1]
            else:
                metadata_max_seqlen_q = max_seqlen_q
            if max_seqlen_k is None:
                metadata_max_seqlen_k = int(kv_seqlens.max().item())
                fwd_max_seqlen_k = metadata_max_seqlen_k
            else:
                metadata_max_seqlen_k = max_seqlen_k
            scheduler_metadata = get_scheduler_metadata(
                max_seqlen_q=metadata_max_seqlen_q,
                max_seqlen_k=metadata_max_seqlen_k,
                nheads=q.shape[1] if q.dim() == 3 else q.shape[2],
                nheads_kv=k.shape[1] if k.dim() == 3 else k.shape[2],
                headdim=q.shape[-1],
                num_splits=num_splits,
                headdim_v=v.shape[-1],
                pack_gqa=pack_gqa,
                causal=causal,
                window_size_left=window_size[0],
                window_size_right=window_size[1],
                seqused_k=kv_seqlens,
                seqused_q=seqused_q,
                cu_seqlens_q=cu_seqlens_q,
                qkv_dtype=q.dtype,
            )

        out, softmax_lse, out_accum, softmax_lse_accum = _flash_attn_forward(
            q,
            k,
            v,
            qv,
            None,
            cu_seqlens_q,
            cu_seqlens_k,
            max_seqlen_q,
            fwd_max_seqlen_k,
            min_seqlen_k,
            seqused_q,
            seqused_k,
            gather_kv_indices,
            page_table,
            softmax_scale,
            causal,
            window_size[0],
            window_size[1],
            learnable_sink,
            softcap,
            num_splits,
            pack_gqa,
            True,
            scheduler_metadata,
            layout,
        )

        ctx.save_for_backward(
            q,
            k,
            v,
            out,
            softmax_lse,
            cu_seqlens_q,
            cu_seqlens_k,
            _full_contiguous(seqused_q),
            _full_contiguous(seqused_k),
        )
        ctx.max_seqlen_q = max_seqlen_q
        ctx.max_seqlen_k = max_seqlen_k
        ctx.softmax_scale = softmax_scale
        ctx.causal = causal
        ctx.window_size = window_size
        ctx.softcap = softcap
        ctx.deterministic = deterministic
        ctx.return_lse = return_lse
        ctx.pack_gqa = pack_gqa
        ctx.qv = qv
        ctx.page_table = page_table
        ctx.gather_kv_indices = gather_kv_indices
        ctx.learnable_sink = learnable_sink
        ctx.score_mod = score_mod
        ctx.score_mod_bwd = score_mod_bwd
        ctx.mask_mod = mask_mod
        ctx.block_sparse_tensors = block_sparse_tensors
        ctx.aux_tensors = aux_tensors
        ctx.aux_scalars = aux_scalars

        if return_lse:
            return out, softmax_lse, out_accum, softmax_lse_accum
        return out

    @staticmethod
    def backward(ctx, dout, *args):
        q, k, v, out, softmax_lse, cu_seqlens_q, cu_seqlens_k, seqused_q, seqused_k = (
            ctx.saved_tensors
        )
        dlse = args[0] if ctx.return_lse and len(args) > 0 else None
        if dlse is not None and torch.is_tensor(dlse) and float(dlse.detach().abs().sum()) == 0.0:
            dlse = None
        win_l, win_r = ctx.window_size
        if win_l is not None and win_l < 0:
            win_l = None
        if win_r is not None and win_r < 0:
            win_r = None

        dq, dk, dv = _flash_attn_backward(
            q,
            k,
            v,
            out,
            dout,
            softmax_lse,
            softmax_scale=ctx.softmax_scale,
            causal=ctx.causal,
            softcap=ctx.softcap,
            window_size_left=win_l,
            window_size_right=win_r,
            cu_seqlens_q=cu_seqlens_q,
            cu_seqlens_k=cu_seqlens_k,
            seqused_q=seqused_q,
            seqused_k=seqused_k,
            max_seqlen_q=ctx.max_seqlen_q,
            max_seqlen_k=ctx.max_seqlen_k,
            deterministic=ctx.deterministic,
            pack_gqa=bool(ctx.pack_gqa) if ctx.pack_gqa is not None else False,
            score_mod=ctx.score_mod,
            score_mod_bwd=ctx.score_mod_bwd,
            mask_mod=ctx.mask_mod,
            aux_tensors=ctx.aux_tensors,
            aux_scalars=ctx.aux_scalars,
            block_sparse_tensors=ctx.block_sparse_tensors,
            dlse=dlse,
            qv=ctx.qv,
            page_table=ctx.page_table,
            gather_kv_indices=ctx.gather_kv_indices,
            learnable_sink=ctx.learnable_sink,
        )
        return (
            dq,
            dk,
            dv,
            None,  # qv
            None,  # cu_seqlens_q
            None,  # cu_seqlens_k
            None,  # max_seqlen_q
            None,  # max_seqlen_k
            None,  # min_seqlen_k
            None,  # seqused_q
            None,  # seqused_k
            None,  # gather_kv_indices
            None,  # page_table
            None,  # softmax_scale
            None,  # causal
            None,  # window_size
            None,  # learnable_sink
            None,  # softcap
            None,  # num_splits
            None,  # pack_gqa
            None,  # deterministic
            None,  # score_mod
            None,  # score_mod_bwd
            None,  # mask_mod
            None,  # block_sparse_tensors
            None,  # aux_tensors
            None,  # aux_scalars
            None,  # return_lse
            None,  # scheduler_metadata
            None,  # disable_scheduler_metadata
        )


def flash_attn_func(
    q,
    k,
    v,
    qv=None,
    gather_kv_indices=None,
    softmax_scale=None,
    causal: bool = False,
    window_size=(-1, -1),
    learnable_sink=None,
    softcap=0.0,
    num_splits=1,
    pack_gqa=None,
    deterministic: bool = False,
    score_mod=None,
    score_mod_bwd=None,
    mask_mod=None,
    aux_tensors=None,
    aux_scalars=None,
    block_sparse_tensors=None,
    block_sparse_tensors_bwd=None,
    return_lse: bool = False,
    scheduler_metadata: Optional[torch.Tensor] = None,
    disable_scheduler_metadata: bool = False,
):
    if q.dtype == torch.float8_e4m3fn:
        if qv is not None:
            raise NotImplementedError("Ascend950 V4 FP8 supports q/k/v inputs only")
        if any(t is not None and t.requires_grad for t in (q, k, v)):
            raise NotImplementedError("Ascend950 V4 FP8 supports inference forward only")
    return FlashAttnFunc.apply(
        q,
        k,
        v,
        qv,
        gather_kv_indices,
        softmax_scale,
        causal,
        window_size,
        learnable_sink,
        softcap,
        num_splits,
        pack_gqa,
        deterministic,
        score_mod,
        score_mod_bwd,
        mask_mod,
        aux_tensors,
        aux_scalars,
        block_sparse_tensors,
        block_sparse_tensors_bwd,
        return_lse,
        scheduler_metadata,
        disable_scheduler_metadata,
    )


@_torch_custom_op_wrapper(
    "flash_attn_npu_4_950::_flash_attn_combine",
    mutates_args=("out",),
    device_types="npu",
)
def _flash_attn_combine_op(
    out_partial: torch.Tensor,
    lse_partial: torch.Tensor,
    out: torch.Tensor,
    out_dtype: Optional[torch.dtype],
    cu_seqlens: Optional[torch.Tensor],
    seqused: Optional[torch.Tensor],
    virtual_batch_idx: Optional[torch.Tensor],
    return_lse: bool,
) -> torch.Tensor:
    result = flash_attn_npu_4_950.fwd_combine(
        out_partial,
        lse_partial,
        out,
        out_dtype,
        cu_seqlens,
        seqused,
        virtual_batch_idx,
        return_lse,
    )
    return result[1] if return_lse else torch.empty(0, dtype=torch.float32, device=result[0].device)


@_torch_register_fake_wrapper("flash_attn_npu_4_950::_flash_attn_combine")
def _flash_attn_combine_fake(
    out_partial: torch.Tensor,
    lse_partial: torch.Tensor,
    out: torch.Tensor,
    out_dtype: Optional[torch.dtype],
    cu_seqlens: Optional[torch.Tensor],
    seqused: Optional[torch.Tensor],
    virtual_batch_idx: Optional[torch.Tensor],
    return_lse: bool,
) -> torch.Tensor:
    is_dense = out_partial.dim() == 5
    if not return_lse:
        return torch.empty(0, dtype=torch.float32, device=out.device)
    lse_shape = (
        (out_partial.shape[1], out_partial.shape[2], out_partial.shape[3])
        if is_dense
        else (out_partial.shape[1], out_partial.shape[2])
    )
    return torch.empty(lse_shape, dtype=torch.float32, device=out.device)


def flash_attn_combine(
    out_partial: torch.Tensor,
    lse_partial: torch.Tensor,
    out: Optional[torch.Tensor] = None,
    out_dtype: Optional[torch.dtype] = None,
    cu_seqlens: Optional[torch.Tensor] = None,
    seqused: Optional[torch.Tensor] = None,
    virtual_batch_idx: Optional[torch.Tensor] = None,
    return_lse: bool = True,
) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
    """Merge split-KV partial attention outputs (FA4, Ascend 950 backend).

    ``cu_seqlens``/``seqused`` are accepted and validated for API parity but do
    not currently limit the processed rows.
    """
    if out is None:
        output_dtype = out_dtype or out_partial.dtype
        out_shape = (
            out_partial.shape[1:4] + (out_partial.shape[4],)
            if out_partial.dim() == 5
            else out_partial.shape[1:2] + out_partial.shape[2:4]
        )
        out = torch.empty(out_shape, dtype=output_dtype, device=out_partial.device)
    lse = _flash_attn_combine_op(
        out_partial,
        lse_partial,
        out,
        out_dtype,
        cu_seqlens,
        seqused,
        virtual_batch_idx,
        return_lse,
    )
    return out, lse if return_lse else None


@_torch_register_fake_wrapper("flash_attn_npu_4_C::_flash_attn_forward")
def _flash_attn_forward_fake(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    qv: Optional[torch.Tensor] = None,
    out_: Optional[torch.Tensor] = None,
    cu_seqlens_q: Optional[torch.Tensor] = None,
    cu_seqlens_k: Optional[torch.Tensor] = None,
    max_seqlen_q: Optional[int] = None,
    max_seqlen_k: Optional[int] = None,
    min_seqlen_k: Optional[int] = None,
    seqused_q: Optional[torch.Tensor] = None,
    seqused_k: Optional[torch.Tensor] = None,
    gather_kv_indices: Optional[torch.Tensor] = None,
    page_table: Optional[torch.Tensor] = None,
    softmax_scale: Optional[float] = None,
    causal: bool = False,
    window_size_left: int = -1,
    window_size_right: int = -1,
    learnable_sink: Optional[torch.Tensor] = None,
    softcap: float = 0.0,
    num_splits: int = 0,
    pack_gqa: Optional[bool] = None,
    return_lse: bool = False,
    scheduler_metadata: Optional[torch.Tensor] = None,
    layout: int = _LAYOUT_BSND,
    q_descale: Optional[torch.Tensor] = None,
    k_descale: Optional[torch.Tensor] = None,
    v_descale: Optional[torch.Tensor] = None,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    """Metadata-only fake for V4 A3 forward. Returns 4-tuple."""
    is_varlen_q = cu_seqlens_q is not None
    head_size_v = v.shape[-1]
    out_dtype = torch.bfloat16 if q.dtype == torch.float8_e4m3fn else q.dtype

    if is_varlen_q:
        total_q = q.shape[0]
        num_heads = q.shape[1]
        out = torch.empty((total_q, num_heads, head_size_v), dtype=out_dtype, device=q.device)
        if return_lse:
            softmax_lse = torch.empty((num_heads, total_q), dtype=torch.float32, device=q.device)
        else:
            softmax_lse = torch.empty((0,), dtype=torch.float32, device=q.device)
    elif layout == _LAYOUT_BNSD:
        batch_size, num_heads, seqlen_q = q.shape[0], q.shape[1], q.shape[2]
        out = torch.empty(
            (batch_size, seqlen_q, num_heads, head_size_v),
            dtype=out_dtype,
            device=q.device,
        )
        if return_lse:
            softmax_lse = torch.empty(
                (batch_size, num_heads, seqlen_q),
                dtype=torch.float32,
                device=q.device,
            )
        else:
            softmax_lse = torch.empty((0,), dtype=torch.float32, device=q.device)
    else:
        batch_size = q.shape[0]
        seqlen_q = q.shape[1]
        num_heads = q.shape[2]
        out = torch.empty(
            (batch_size, seqlen_q, num_heads, head_size_v),
            dtype=out_dtype,
            device=q.device,
        )
        if return_lse:
            softmax_lse = torch.empty(
                (batch_size, num_heads, seqlen_q),
                dtype=torch.float32,
                device=q.device,
            )
        else:
            softmax_lse = torch.empty((0,), dtype=torch.float32, device=q.device)

    # Real mha_fwd currently always returns empty accum tensors.
    out_accum = torch.empty((0,), dtype=torch.float32, device=q.device)
    softmax_lse_accum = torch.empty((0,), dtype=torch.float32, device=q.device)
    return out, softmax_lse, out_accum, softmax_lse_accum


def flash_attn_varlen_func(
    q,
    k,
    v,
    qv=None,
    cu_seqlens_q: Optional[torch.Tensor] = None,
    cu_seqlens_k: Optional[torch.Tensor] = None,
    max_seqlen_q: Optional[int] = None,
    max_seqlen_k: Optional[int] = None,
    min_seqlen_k: Optional[int] = None,
    seqused_q=None,
    seqused_k=None,
    gather_kv_indices: Optional[torch.Tensor] = None,
    page_table: Optional[torch.Tensor] = None,
    softmax_scale=None,
    causal: bool = False,
    window_size=(-1, -1),
    learnable_sink: Optional[torch.Tensor] = None,
    softcap=0.0,
    num_splits=0,
    pack_gqa=None,
    deterministic: bool = False,
    score_mod=None,
    score_mod_bwd=None,
    mask_mod=None,
    block_sparse_tensors=None,
    aux_tensors=None,
    aux_scalars=None,
    return_lse: bool = False,
    scheduler_metadata: Optional[torch.Tensor] = None,
    disable_scheduler_metadata: bool = False,
):
    if q.dtype == torch.float8_e4m3fn:
        if qv is not None:
            raise NotImplementedError("Ascend950 V4 FP8 supports q/k/v inputs only")
        if any(t is not None and t.requires_grad for t in (q, k, v)):
            raise NotImplementedError("Ascend950 V4 FP8 supports inference forward only")
    return FlashAttnVarlenFunc.apply(
        q,
        k,
        v,
        qv,
        cu_seqlens_q,
        cu_seqlens_k,
        max_seqlen_q,
        max_seqlen_k,
        min_seqlen_k,
        seqused_q,
        seqused_k,
        gather_kv_indices,
        page_table,
        softmax_scale,
        causal,
        window_size,
        learnable_sink,
        softcap,
        num_splits,
        pack_gqa,
        deterministic,
        score_mod,
        score_mod_bwd,
        mask_mod,
        block_sparse_tensors,
        aux_tensors,
        aux_scalars,
        return_lse,
        scheduler_metadata,
        disable_scheduler_metadata,
    )
